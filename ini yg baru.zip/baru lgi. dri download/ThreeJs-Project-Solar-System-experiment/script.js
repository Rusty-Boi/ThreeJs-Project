function removeUI(){
    var elementToRemove = document.querySelector('.overlay')
    elementToRemove.remove()
    
}